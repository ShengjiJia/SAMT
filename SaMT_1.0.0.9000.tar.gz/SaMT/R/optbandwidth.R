#' @title Optimal bandwidth selection 
#'
#' @description 
#' \code{optbandwidth} provides the optimal bandwidth selection for screening and multiple testing (SaMT) procedure.
#'
#' @details
#' \code{optbandwidth} provides the optimal bandwidth selection for screening and multiple testing procedure, which is based on 
#' order preserved sample splitting strategy. The bandwidth h1 is used in \code{screening}, h2 is used in \code{localtest}. 
#'
#' @param y the response vector
#' @param x the position (vector) of y
#' @param h1 the vector of candidate bandwidths used in \code{screening}
#' @param h2 the vector of candidate bandwidths used in \code{localtest}
#'
#' @return the optimal values of h1 and h2
#'
#' @import np
#' @import KernSmooth
#' @export 
#'
#' @examples
#' set.seed(23)
#' x=(1:2000)/2000
#' tau=sort(sample(1:49, size=20, replace = FALSE))/50
#' beta=sample(c(-2,-1,-0.5,0.5,1,2), size=20, replace = TRUE)
#' y=exp(-x)+rnorm(2000,mean=0,sd=0.2)
#' for(i in 1:20){ y<-y+beta[i]*(x>tau[i]) }
#' optbandwidth(y,x,h1=c(15/2000,20/2000,25/2000),h2=c(0.05,0.1,0.15))

optbandwidth<-function (y, x, h1, h2){
  nn=length(x)
  n1=length(h1)
  n2=length(h2)
  x_odd=x[2*(1:floor(nn/2))-1]
  x_even=x[2*(1:floor(nn/2))]
  y_odd=y[2*(1:floor(nn/2))-1]
  y_even=y[2*(1:floor(nn/2))]
  RSS=seq(from=0,to=0,length.out=n1*n2)
  hh1=as.vector(matrix(rep(h1,n2),nr=n2, byrow=TRUE))
  hh2=rep(h2,n1)
  for(j in 1:(n1*n2)){
    h=hh1[j]
    L=abs(screening(y_even,x_even,h))
    lambda=4*mad(L)
    n=length(x_even)
    x1=localMax(L,floor(h*n))/n
    candidate=x1[which(L[localMax(L,floor(h*n))]>lambda)]
    x2=c(0,(candidate[1:(length(candidate)-1)]+candidate[2:length(candidate)])/2,1.01)
    pvalue=1:length(candidate)
    for(i in 1:length(candidate)){
      subx=x[which((x>x2[i])&(x<x2[i+1]))]
      suby=y[which((x>x2[i])&(x<x2[i+1]))]
      test=localtest(suby,subx,candidate[i],max(10,hh2[j]*length(subx))/n)
      pvalue[i]=pchisq(test,df=1,lower.tail=FALSE)
    }
    estimate1=candidate[which(p.adjust(pvalue, "BH")<0.1)]
    jump=0 
    for(i in 1:length(estimate1)){
      jump<-jump+L[(estimate1[i]*n)]*(x_even>estimate1[i])
    }
    h3=dpill(x_even,(y_even-jump))
    fitted=locpoly(x_even,(y_even-jump),bandwidth=h3,gridsize=nn+1,range.x=c(0,1))$y[2*(1:floor(nn/2))]+jump
    RSS[j]=sum(y_odd-fitted)^2
  }
  return(c(hh1[which.min(RSS)],hh2[which.min(RSS)]))
}