#' @title Extract local maximizers of a sequence
#'
#' @description
#' \code{localMax} provides local maximizers of a sequence.
#'
#' @details
#' If a bandwidth h is used, the \code{span} should be the integer part of length(y)*h.
#'
#' @param y the input sequence
#' @param span an integer (the number of data points in the neighborhood)
#'
#' @return index of the local maximizers in the sequence
#'
#' @export
#'
#' @examples
#' y=rnorm(200,mean=0,sd=1)
#' localMax(y,span=10)

localMax <-function(y, span = 10){
  if (length(y) < span * 2 + 1)  return(NULL)
  n  = length(y)
  index = NULL
  for (i in (span + 1) : (n - span) ) {
    if ( y[i] == max(y[(i - span) : (i + span)]) ) index = c(index, i)
  }
  return (index)
}
