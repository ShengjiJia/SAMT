#' @title CGHdata Dataset 
#'
#' @description 
#' A data frame containing 57 bladder tumor samples, as used in Stransky et al. 2006. 
#'
#' @sourse
#' The data can be downloaded from the 
#' \href{http://microarrays.curie.fr/publications/oncologie_moleculaire/bladder_TCM/}
#'
#' @format A data frame with 2385 rows and 174 variables:
#' \describe{
#' \item{\code{BAC}}{character. BAC clones.}
#' \item{\code{Chromosome}}{integer. Chromosome number.}
#' \item{\code{Position}}{integer. Genomic positions according to the may 2004 freeze of the UCSC Genome Reference Sequence.}
#' \item{log2ratio}{double. log 2 ratios.}
#' \item{GNL}{integer. GNL status.}
#' \item{Outlier}{integer. Outlier status.}
#' }
"CGHdata"