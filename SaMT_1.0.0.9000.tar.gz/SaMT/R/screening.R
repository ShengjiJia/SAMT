#' @title Calculate the difference process 
#'
#' @description 
#' \code{screening} provides the difference process in the screening procedure.
#'
#' @details
#' If bandwidth h is used, \code{screening} shows the right-limit minus left-limit at each position in x. 
#' The difference process at boundary points are set to zero. 
#'
#' @param y the response vector
#' @param x the position (vector) of y
#' @param h the bandwidth used to calculate right-limit minus left-limit
#'
#' @return right-limit minus left-limit at each position in x
#'
#' @export 
#'
#' @examples
#' x=(1:100)/100
#' y=exp(-x)+0.5*(x>0.6)+rnorm(100,mean=0,sd=0.1)
#' abs(screening(y,x,0.1))

screening<-function(y, x, h){
  n=length(x)
  rkernal<-function(t){
    0.75*(1-((x-t)/h)^2)*(((x-t)/h)>=0)*(((x-t)/h)<=1)
  }
  lkernal<-function(t){
    0.75*(1-((x-t)/h)^2)*(((x-t)/h)>=-1)*(((x-t)/h)<0)
  }
  rweight<-function(t){
    rkernal(t)*(sum(rkernal(t)*(x-t)^2)-(x-t)*sum(rkernal(t)*(x-t)))
  }
  lweight<-function(t){
    lkernal(t)*(sum(lkernal(t)*(x-t)^2)-(x-t)*sum(lkernal(t)*(x-t)))
  }
  rlimit<-function(t){
    sum(rweight(t)*y)/sum(rweight(t))
  }
  llimit<-function(t){
    sum(lweight(t)*y)/sum(lweight(t))
  }
  right=rep(0,n)
  for (i in 1:(n-1)){
    right[i]=rlimit(x[i])   
  }
  left=rep(0,n)
  for (i in 2:n){
    left[i]=llimit(x[i])
  }
  L=right-left
  for(i in 1:floor(h*n)){
    L[i]=0
  }
  for(i in (n-floor(h*n)):n){
    L[i]=0
  }
  return(L)
}