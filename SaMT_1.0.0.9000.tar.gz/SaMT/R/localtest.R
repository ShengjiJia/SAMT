#' @title Calculate the local test statistic 
#'
#' @description 
#' \code{localtest} provides the Wald statistic for testing a potential jump point t0.
#'
#' @details
#' \code{localtest} provides the Wald statistic based on profile likelihood, to test whether t0 is a jump point in a sequence. 
#' The bandwidth h is used in the partially linear model. 
#'
#' @param y the response vector
#' @param x the position (vector) of y
#' @param t0 the potential jump point to be tested
#' @param h the bandwidth used in the partially linear model
#'
#' @return the Wald test statistic
#'
#' @import np
#' @export 
#'
#' @examples
#' x=(1:100)/100
#' y=exp(-x)+0.5*(x>0.6)+rnorm(100,mean=0,sd=0.1)
#' localtest(y,x,0.6,h=0.1)

localtest<-function (y, x, t0, h){
  W=function(t,x,h){diag(1/h*3/4*(1-((x-t)/h)^2)*((1-((x-t)/h)^2)>0))}
  D=function(t,x,h){matrix(c(rep(1,times=length(x)),(x-t)/h),nrow=length(x),ncol=2)}
  s=function(t,x,h){t(c(1,0))%*%solve(t(D(t,x,h))%*%W(t,x,h)%*%D(t,x,h))%*%t(D(t,x,h))%*%W(t,x,h)}
  S=NULL                                                            #smooth matrix S
  for(i in 1:length(x)){S=rbind(S,s(x[i],x,h))}
  z=1*(x>t0)
  Z=(diag(1,length(x))-S)%*%z                             #tildeZ
  Y=(diag(1,length(x))-S)%*%y                             #tildeY
  r=lm(Y~0+Z)$residuals
  fit=npreg(r^2~x,regtype="ll",ckertype="epanechnikov")
  sigma=diag(fit$mean)
  Wald=(t(Z)%*%Y)^2/sum(fit$mean*(Z^2))
  Wald
}